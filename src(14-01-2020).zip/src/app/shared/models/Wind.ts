export interface Wind {
  city: string;
  value: number;
}
