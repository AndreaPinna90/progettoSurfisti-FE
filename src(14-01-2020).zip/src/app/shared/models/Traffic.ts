export interface Traffic {
  city: string;
  value: number;
}
